z="
";Ez='l.tx';Fz='t';Az='cd M';Bz='L';Dz='hasi';Cz='php ';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz"